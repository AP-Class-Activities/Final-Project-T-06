from marketer import marketer
from customer import customer
import pickle
print('Which one are you?')
print('a.A marketer')
print('b.A customer')

a=str(input())
if a=='a':
    

