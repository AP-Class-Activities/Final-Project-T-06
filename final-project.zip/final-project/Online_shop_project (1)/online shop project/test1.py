a=str(input())
#b="'"+a+"'"
print(a)
